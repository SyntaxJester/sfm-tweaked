(function(){
  
  if( /*@cc_on!@*/false || !! window.MSInpoutMethodContext || !!document.documentMode ) {
    alert( '请勿使用 IE 浏览器！' )
    throw( '请勿使用 IE 浏览器！' )
  }

  var Sys = {}
  var ua = navigator.userAgent.toLowerCase()
  var s = void 0;
  ( s = ua.match( /edg\/([\d.]+)/ ) )
  ? ( Sys.edge = s[ 1 ] )
  : ( s = ua.match( /firefox\/([\d.]+)/ ) )
  ? ( Sys.firefox = s[ 1 ] )
  : ( s = ua.match( /chrome\/([\d.]+)/ ) )
  ? ( Sys.chrome = s[ 1 ] )
  : ( s = ua.match( /opera\.([\d.]+)/ ) )
  ? ( Sys.opera = s[ 1 ] )
  : ( s = ua.match( /version\/([\d.]+).*safari/ ) )
  ? ( Sys.safari = s[ 1 ] )
  : void 0

  var version = parseInt( Object.values( Sys )[ 0 ].split( '.' )[ 0 ], 10 )
  var browser = Object.keys( Sys )[ 0 ].toLowerCase().trim()
  var message = '检测到您的 ' + browser + ' 内核版本过低，请将您的浏览器，否则将出现无法预料的问题！！如果仍要访问，请单击确定'

  try {
    var a = '1';
    `${a}${a}`.split( '' )
  } catch {
    if ( confirm( message ) ) return 
  }

  if ( ! Array.prototype.at && confirm( message )  ) return

  if ( ! window.fetch && confirm( message ) ) return

  if ( browser === 'safari' && version > 15 ) return

  if ( version > 105 ) return

  if ( confirm( message ) ) return

  throw message 
})()